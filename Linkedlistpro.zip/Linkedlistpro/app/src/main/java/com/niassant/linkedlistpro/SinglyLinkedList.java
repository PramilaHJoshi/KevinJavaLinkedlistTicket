package com.niassant.linkedlistpro;

import java.util.LinkedList;
import java.util.Scanner;

/**
 * Created by Niassant Softcom Pvt. Ltd. on 01-Feb-18.
 */

public class SinglyLinkedList {
    public static void main(String args[])
    {
        Scanner scan = new Scanner(System.in);
        /*Crating object of class linkedlist*/
        linkedList list = new linkedList();
        System.out.println("Singly Linked list test\n");
        char ch;
        do {
            System.out.println("Singly Linked list operations\n");
            System.out.println("1: Insert at begining \n");
            System.out.println("2: Insert at end\n");
            System.out.println("3: Insert at position\n");
            System.out.println("4: delete at position\n");
            System.out.println("5: check empty\n");
            System.out.println("6: get size\n");
            System.out.println("7: Delete All\n");
            System.out.println("8: Delete Tail\n");
            int choice = scan.nextInt();

            switch (choice)
            {
                case 1 :
                    System.out.println("Enter integer element to insert\n");
                    list.insertAtStart(scan.nextInt());
                    break;
                case 2 :
                    System.out.println("Enter integer element to insert\n");
                    list.insertAtEnd(scan.nextInt());
                    break;
                case 3 :
                    System.out.println("Enter integer element to insert\n");
                   int num = scan.nextInt();
                    System.out.println("Enter position\n");
                    int pos = scan.nextInt();
                    if(pos <=1 || pos > list.getSize())
                    {

                        System.out.println("invalid position\n");

                    }
                    else
                    {
                        list.insertAtPos(num, pos);


                    }
                    break;
                case 4 :
                    System.out.println("Enter Position");
                    int p = scan.nextInt();
                    if(p < 1 || p > list.getSize())
                    {

                        System.out.println("invalid position\n");

                    }
                    else
                    {
                        list.deleteAtpos(p);
                    }
                break;
                case 5 :
                    System.out.println("Empty Status " + list.isEmpty());
                break;
                case 6 :
                    System.out.println("Size " + list.getSize() +"\n");
                    break;
                case 7 :
                    System.out.println("Delete all");
                    list.delall();
                break;
                case 8 :
//                    System.out.println("Enter Position");
                   // int q = scan.nextInt();

                        list.deletetail();
                        break;
                default:
                    System.out.println("Wrong Entry \n");
            }
            /*Display List*/
            list.display();
            System.out.println("\n Do you want to continue (Type y or n) \n");
            ch = scan.next().charAt(0);

        }while (ch=='Y' || ch=='y');

    }
}
