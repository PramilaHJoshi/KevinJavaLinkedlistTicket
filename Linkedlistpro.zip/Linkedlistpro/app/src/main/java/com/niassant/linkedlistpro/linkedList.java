package com.niassant.linkedlistpro;

/**
 * Created by Niassant Softcom Pvt. Ltd. on 01-Feb-18.
 */

public class linkedList {

    public   Node start;
    public   Node end;
    public int size;

/*Constructor*/
    public linkedList()
    {
        start = null;
        end = null;
        size= 0;
    }
/* function to check if list is empyt*/
    public boolean isEmpty()
    {
        return start == null;
    }

    public int getSize()
    {
        return size;
    }
 /* function to insert an element in begining*/
    public void insertAtStart(int val)
    {
    Node nptr = new Node(val, null);
        size++ ;
        if(start == null)
        {
            start = nptr;
            end = start;
        }
        else
        {
            nptr.setLink(start);
            start = nptr;
        }


    }
/* function to insert an element in begining*/
    public void insertAtEnd(int val)
    {
    Node nptr = new Node(val, null);
        size++ ;
        if(start==null)
        {
            start = nptr;
            end = start;
        }
        else
        {
            end.setLink(nptr);
            end = nptr;
        }

    }

/* function to insert an element in begining*/
    public void insertAtPos(int val, int pos)
    {
     Node nptr = new Node(val, null);
     Node ptr = start;
        pos = pos - 1;
        for(int i = 1; i < size ; i++)
        {
            if( i == pos)
            {
                Node tmp = ptr.getLink();
                ptr.setLink(nptr);
                nptr.setLink(tmp);
                break;
            }
            ptr = ptr.getLink();

        }
        size++;

    }


    /* function to insert an element at positoin*/
    public void deleteAtpos(int pos)
    {
        if(pos == 1)
        {
            start = start.getLink();
            size--;
            return;
        }
        if(pos == size)
        {
            Node s = start;
            Node t = start;
            while(s != end)
            {
            t = s;
            s = s.getLink();

            }
            end = t;
            end.setLink(null);
            size --;
            return;
        }
        Node ptr = start;
        pos = pos - 1;
        for(int i =1; i<size -1; i++)
        {
            if(i == pos)
            {
                Node temp = ptr.getLink();
                temp = temp.getLink();
                ptr.setLink(temp);
                break;
            }
            ptr = ptr.getLink();

        }
        size--;

    }

    /* function to insert an element at positoin*/
    public void deletetail()
    {
        if(size == 1)
        {
            start = start.getLink();
            size--;
            return;
        }
        if(size == size)
        {
            Node s = start;
            Node t = start;
            while(s != end)
            {
                t = s;
                s = s.getLink();

            }
            end = t;
            end.setLink(null);
            size --;
            return;
        }
        Node ptr = start;
      //  pos = pos - 1;
        for(int i =1; i<size -1; i++)
        {
            if(i == size)
            {
                Node temp = ptr.getLink();
                temp = temp.getLink();
                ptr.setLink(temp);
                break;
            }
            ptr = ptr.getLink();

        }
        size--;

    }
/*Function to display element*/
    public void display()
    {
        System.out.print("\n Singly Linked List = ");
        if(size == 0)
        {
            System.out.print("empty\n");
            return;
        }
        if(start.getLink() == null)
        {
            System.out.println(start.getData());
            return;
        }
        Node ptr = start;
        System.out.print(start.getData()+ "->");
        ptr = start.getLink();
        while(ptr.getLink() != null)
        {
            System.out.println(ptr.getData());
            ptr = ptr.getLink();

        }
        System.out.print(ptr.getData()+ "\n");
    }

    public void delall()
    {
        size = 0;
        start = null;
        end = null;


    }

}
